WHAT I DID

**********

First, I uploaded the C code file to my tux account.
minmax_iterative.c

I then ran the proper mips-gcc commands to generate both lst and s files.
minmax_iterative.lst
minmax_iterative.s

Finally, I reveiewed the code of the s file and the c file, and commented both of them.
The commented version of the minmax_iterative.s file is called minmax_iterative_commented.s.